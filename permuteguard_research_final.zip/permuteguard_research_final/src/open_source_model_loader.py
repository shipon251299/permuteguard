import os
from typing import Dict, Tuple

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


class OpenSourceModelLoader:
    """Clean loader for local open-source causal language models."""

    SUPPORTED_MODEL_TYPES = {"gpt2", "tinyllama", "mistral", "falcon", "bloom", "opt"}

    @staticmethod
    def _trust_remote_code(model_type: str) -> bool:
        return model_type in {"mistral", "falcon", "tinyllama", "opt", "bloom"}

    @staticmethod
    def _use_fast(model_type: str) -> bool:
        return model_type not in {"mistral"}

    @staticmethod
    def _infer_default_policy(model_type: str) -> str:
        if model_type == "gpt2":
            return "fp32_single"
        if model_type == "tinyllama":
            return "fp16_auto"
        return "int8_auto"

    @staticmethod
    def _visible_gpu_count() -> int:
        return torch.cuda.device_count() if torch.cuda.is_available() else 0

    @staticmethod
    def _max_memory_map(per_gpu_gib: int = 18, cpu_gib: int = 120) -> Dict:
        gpu_count = OpenSourceModelLoader._visible_gpu_count()
        if gpu_count == 0:
            return {}
        max_memory = {i: f"{per_gpu_gib}GiB" for i in range(gpu_count)}
        max_memory["cpu"] = f"{cpu_gib}GiB"
        return max_memory

    @staticmethod
    def _print_placement_summary(model) -> None:
        device_map = getattr(model, "hf_device_map", None)
        if device_map is None:
            try:
                print("placement:", next(model.parameters()).device)
            except Exception:
                print("placement: unknown")
            return

        summary = {}
        for _, dev in device_map.items():
            summary[str(dev)] = summary.get(str(dev), 0) + 1
        print("hf_device_map summary:", summary)
        print("hf_device_map:", device_map)

    @staticmethod
    def get_input_device(model) -> torch.device:
        try:
            emb = model.get_input_embeddings()
            return emb.weight.device
        except Exception:
            try:
                return next(model.parameters()).device
            except Exception:
                return torch.device("cpu")

    @staticmethod
    def load_model(
        model_path: str,
        model_type: str,
        load_policy: str = "auto",
        max_gpu_memory_gib: int = 18,
        cpu_memory_gib: int = 120,
        enable_cpu_offload: bool = True,
    ) -> Tuple[torch.nn.Module, AutoTokenizer]:
        if model_type not in OpenSourceModelLoader.SUPPORTED_MODEL_TYPES:
            raise ValueError(f"Unsupported model_type: {model_type}")
        if not os.path.isdir(model_path):
            raise ValueError(f"Model path does not exist: {model_path}")

        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

        trust_remote_code = OpenSourceModelLoader._trust_remote_code(model_type)
        use_fast = OpenSourceModelLoader._use_fast(model_type)

        tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            local_files_only=True,
            trust_remote_code=trust_remote_code,
            use_fast=use_fast,
        )
        if tokenizer.pad_token is None and tokenizer.eos_token is not None:
            tokenizer.pad_token = tokenizer.eos_token

        if load_policy == "auto":
            load_policy = OpenSourceModelLoader._infer_default_policy(model_type)

        print(f"Loading {model_type} from local path: {model_path}")
        print(f"load_policy={load_policy}")

        common = dict(
            pretrained_model_name_or_path=model_path,
            local_files_only=True,
            trust_remote_code=trust_remote_code,
            low_cpu_mem_usage=True,
        )

        if load_policy == "fp32_single":
            model = AutoModelForCausalLM.from_pretrained(
                **common,
                torch_dtype=torch.float32,
                device_map=None,
            )
            if torch.cuda.is_available():
                model = model.to("cuda:0")

        elif load_policy == "fp16_auto":
            if not torch.cuda.is_available():
                model = AutoModelForCausalLM.from_pretrained(
                    **common,
                    torch_dtype=torch.float32,
                    device_map=None,
                )
            else:
                model = AutoModelForCausalLM.from_pretrained(
                    **common,
                    torch_dtype=torch.float16,
                    device_map="auto",
                    max_memory=OpenSourceModelLoader._max_memory_map(
                        per_gpu_gib=max_gpu_memory_gib,
                        cpu_gib=cpu_memory_gib,
                    ),
                    offload_buffers=enable_cpu_offload,
                )

        elif load_policy == "int8_auto":
            if not torch.cuda.is_available():
                model = AutoModelForCausalLM.from_pretrained(
                    **common,
                    torch_dtype=torch.float32,
                    device_map=None,
                )
            else:
                quant_config = BitsAndBytesConfig(
                    load_in_8bit=True,
                    llm_int8_enable_fp32_cpu_offload=enable_cpu_offload,
                )
                model = AutoModelForCausalLM.from_pretrained(
                    **common,
                    device_map="auto",
                    max_memory=OpenSourceModelLoader._max_memory_map(
                        per_gpu_gib=max_gpu_memory_gib,
                        cpu_gib=cpu_memory_gib,
                    ),
                    quantization_config=quant_config,
                    offload_buffers=enable_cpu_offload,
                )
        else:
            raise ValueError(f"Unknown load_policy: {load_policy}")

        OpenSourceModelLoader._print_placement_summary(model)
        return model, tokenizer
