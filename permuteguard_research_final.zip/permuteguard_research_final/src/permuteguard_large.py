
import hashlib
import json
import math
import os
import random
import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_module_by_name(model: nn.Module, name: str) -> nn.Module:
    module = model
    for part in name.split("."):
        module = getattr(module, part)
    return module


def set_module_by_name(model: nn.Module, name: str, new_module: nn.Module) -> None:
    parts = name.split(".")
    parent = model
    for part in parts[:-1]:
        parent = getattr(parent, part)
    setattr(parent, parts[-1], new_module)


def get_input_device(model: nn.Module) -> torch.device:
    try:
        emb = model.get_input_embeddings()
        return emb.weight.device
    except Exception:
        try:
            return next(model.parameters()).device
        except Exception:
            return torch.device("cpu")


def safe_float(value: Any, default: float = float("nan")) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except Exception:
        return default


@dataclass
class LargeWatermarkConfig:
    watermark_key: str
    metadata_dir: str = "experiments"
    permutation_strength: float = 0.003
    fingerprint_k: int = 4096
    verification_threshold: float = 0.80
    max_layers: int = 8
    min_layer_size: int = 50_000
    exclude_embeddings: bool = True
    materialized_dtype: str = "float16"


class PermuteGuardLarge:
    def __init__(self, config: LargeWatermarkConfig):
        self.config = config

    @staticmethod
    def _safe_id(model_id: str) -> str:
        return model_id.replace("/", "_").replace("\\", "_").replace(":", "_")

    def _meta_path(self, model_id: str) -> str:
        os.makedirs(self.config.metadata_dir, exist_ok=True)
        return os.path.join(self.config.metadata_dir, f"{self._safe_id(model_id)}_metadata.json")

    def _seed_from_parts(self, *parts: str) -> int:
        payload = "::".join(parts)
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
        return int(digest, 16) % (2**32)

    def _generator(self, *parts: str) -> torch.Generator:
        g = torch.Generator(device="cpu")
        g.manual_seed(self._seed_from_parts(*parts))
        return g

    @staticmethod
    def _is_excluded_name(name: str) -> bool:
        lowered = name.lower()
        blocked = [
            "embed", "embedding", "wte", "wpe", "word_embeddings",
            "embed_tokens", "embed_positions", "lm_head", "output_projection",
            "output_layer", "norm", "layernorm", "rotary_emb",
        ]
        return any(tok in lowered for tok in blocked)

    @staticmethod
    def _priority(name: str) -> int:
        lowered = name.lower()
        if any(tok in lowered for tok in ["self_attn", "self_attention", "attn", "attention"]):
            if any(tok in lowered for tok in ["o_proj", "dense", "c_proj"]):
                return 0
            if any(tok in lowered for tok in ["q_proj", "query_key_value", "c_attn"]):
                return 1
            return 2
        if any(tok in lowered for tok in ["mlp", "gate_proj", "up_proj", "down_proj", "fc", "dense_h_to_4h", "dense_4h_to_h"]):
            return 3
        return 4

    @staticmethod
    def _extract_block_index(name: str) -> Optional[int]:
        for pat in [r"\.layers\.(\d+)\.", r"\.h\.(\d+)\."]:
            m = re.search(pat, name)
            if m:
                return int(m.group(1))
        return None

    def identify_candidate_layers(self, model: nn.Module) -> List[Tuple[str, int]]:
        raw = []
        for name, module in model.named_modules():
            weight = getattr(module, "weight", None)
            if weight is None or not hasattr(weight, "shape"):
                continue
            if len(weight.shape) != 2:
                continue
            numel = int(weight.numel())
            if numel < self.config.min_layer_size:
                continue
            if self.config.exclude_embeddings and self._is_excluded_name(name):
                continue
            raw.append(
                {
                    "name": name,
                    "numel": numel,
                    "priority": self._priority(name),
                    "block_idx": self._extract_block_index(name),
                }
            )

        if not raw:
            return []

        raw.sort(key=lambda x: (x["priority"], x["block_idx"] if x["block_idx"] is not None else 10**9, -x["numel"], x["name"]))

        best_by_block = {}
        no_block = []
        for cand in raw:
            if cand["block_idx"] is None:
                no_block.append(cand)
            elif cand["block_idx"] not in best_by_block:
                best_by_block[cand["block_idx"]] = cand

        selected = []
        if best_by_block:
            blocks = sorted(best_by_block.keys())
            positions = np.linspace(0, len(blocks) - 1, num=min(self.config.max_layers, len(blocks)))
            picked_blocks = []
            for p in positions:
                block = blocks[int(round(p))]
                if block not in picked_blocks:
                    picked_blocks.append(block)
            for block in blocks:
                if len(picked_blocks) >= min(self.config.max_layers, len(blocks)):
                    break
                if block not in picked_blocks:
                    picked_blocks.append(block)
            selected = [best_by_block[b] for b in picked_blocks]

        used = {x["name"] for x in selected}
        if len(selected) < self.config.max_layers:
            for cand in raw + no_block:
                if cand["name"] not in used:
                    selected.append(cand)
                    used.add(cand["name"])
                if len(selected) >= self.config.max_layers:
                    break

        return [(x["name"], x["numel"]) for x in selected[: self.config.max_layers]]

    def _target_dtype(self, device: torch.device) -> torch.dtype:
        if device.type == "cpu":
            return torch.float32
        return torch.float16 if self.config.materialized_dtype == "float16" else torch.float32

    def materialize_target_modules(self, model: nn.Module, layer_names: Sequence[str]) -> None:
        for layer_name in layer_names:
            module = get_module_by_name(model, layer_name)
            weight = getattr(module, "weight", None)
            if weight is None:
                continue

            device = weight.device
            target_dtype = self._target_dtype(device)
            print(f"Materializing {layer_name} on {device} with dtype {target_dtype}")

            bias = getattr(module, "bias", None)

            if isinstance(module, nn.Linear) and torch.is_floating_point(weight):
                if module.weight.dtype != target_dtype:
                    module.to(device=device, dtype=target_dtype)
                continue

            if hasattr(weight, "dequantize"):
                dense_weight = weight.dequantize().detach().to(device=device, dtype=target_dtype)
            else:
                dense_weight = weight.detach().to(device=device, dtype=target_dtype)

            use_bias = bias is not None
            is_conv1d_layout = dense_weight.ndim == 2 and use_bias and bias.numel() == dense_weight.shape[1]

            if is_conv1d_layout:
                in_features = dense_weight.shape[0]
                out_features = dense_weight.shape[1]
                new_linear = nn.Linear(in_features, out_features, bias=use_bias, dtype=target_dtype, device=device)
                with torch.no_grad():
                    new_linear.weight.copy_(dense_weight.T.contiguous())
                    new_linear.bias.copy_(bias.detach().to(device=device, dtype=target_dtype))
            else:
                out_features, in_features = dense_weight.shape
                new_linear = nn.Linear(in_features, out_features, bias=use_bias, dtype=target_dtype, device=device)
                with torch.no_grad():
                    new_linear.weight.copy_(dense_weight)
                    if use_bias:
                        new_linear.bias.copy_(bias.detach().to(device=device, dtype=target_dtype))

            set_module_by_name(model, layer_name, new_linear)

    def _fingerprint_indices(self, layer_name: str, n: int) -> torch.Tensor:
        k = min(self.config.fingerprint_k, n)
        return torch.randperm(n, generator=self._generator(self.config.watermark_key, layer_name, "fingerprint"))[:k]

    def _compute_fingerprint(self, weight: torch.Tensor, layer_name: str) -> torch.Tensor:
        flat = weight.detach().reshape(-1).float().cpu()
        idx = self._fingerprint_indices(layer_name, flat.numel())
        return flat[idx]

    def _embed_one_layer(self, weight: torch.Tensor, layer_name: str) -> Dict[str, Any]:
        flat = weight.reshape(-1)
        n = flat.numel()
        subset_size = max(1, int(round(self.config.permutation_strength * n)))

        subset_idx = torch.randperm(n, generator=self._generator(self.config.watermark_key, layer_name, "subset"))[:subset_size].to(flat.device)
        reorder = torch.randperm(subset_size, generator=self._generator(self.config.watermark_key, layer_name, "reorder")).to(flat.device)

        original = flat[subset_idx].clone()
        permuted = original[reorder]
        orig_norm = torch.norm(original.float()) + 1e-8
        perm_norm = torch.norm(permuted.float()) + 1e-8
        permuted = permuted * (orig_norm / perm_norm)
        flat[subset_idx] = permuted

        relative_change = float((torch.norm((permuted - original).float()) / (torch.norm(original.float()) + 1e-8)).item())
        return {
            "fingerprint": self._compute_fingerprint(weight, layer_name).tolist(),
            "subset_size": int(subset_size),
            "relative_change": relative_change,
            "numel": int(n),
        }

    def embed_watermark(self, model: nn.Module, model_id: str, selected_layers: Optional[Sequence[str]] = None, already_materialized: bool = False):
        if selected_layers is None:
            selected_layers = [name for name, _ in self.identify_candidate_layers(model)]
        selected_layers = list(selected_layers)
        if not already_materialized:
            self.materialize_target_modules(model, selected_layers)

        layer_metadata = {}
        selected_info = []
        for layer_name in selected_layers:
            module = get_module_by_name(model, layer_name)
            with torch.no_grad():
                layer_metadata[layer_name] = self._embed_one_layer(module.weight.data, layer_name)
            selected_info.append(
                {
                    "name": layer_name,
                    "device": str(module.weight.device),
                    "dtype": str(module.weight.dtype),
                    "shape": list(module.weight.shape),
                }
            )

        metadata = {
            "model_id": model_id,
            "safe_id": self._safe_id(model_id),
            "key_hash": hashlib.sha256(self.config.watermark_key.encode("utf-8")).hexdigest(),
            "config": asdict(self.config),
            "selected_layers": selected_layers,
            "selected_layer_info": selected_info,
            "layer_metadata": layer_metadata,
        }
        with open(self._meta_path(model_id), "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2)
        return model, metadata

    def load_metadata(self, model_id: str) -> Dict[str, Any]:
        path = self._meta_path(model_id)
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def verify_watermark(self, model: nn.Module, model_id: str, watermark_key: Optional[str] = None) -> Dict[str, Any]:
        try:
            meta = self.load_metadata(model_id)
        except FileNotFoundError:
            return {"verified": False, "confidence": 0.0, "layers_checked": 0, "layer_scores": {}, "error": "metadata_missing"}

        if watermark_key is not None:
            supplied_hash = hashlib.sha256(watermark_key.encode("utf-8")).hexdigest()
            if supplied_hash != meta.get("key_hash"):
                return {"verified": False, "confidence": 0.0, "layers_checked": 0, "layer_scores": {}, "error": "watermark_key_mismatch"}

        scores = {}
        total = 0.0
        checked = 0
        for layer_name in meta["selected_layers"]:
            module = get_module_by_name(model, layer_name)
            stored_fp = torch.tensor(meta["layer_metadata"][layer_name]["fingerprint"], dtype=torch.float32)
            current_fp = self._compute_fingerprint(module.weight.data, layer_name)
            num = torch.dot(current_fp, stored_fp)
            den = (torch.norm(current_fp) * torch.norm(stored_fp)) + 1e-8
            conf_tensor = torch.abs(num / den)
            conf = 0.0 if not torch.isfinite(conf_tensor) else float(torch.clamp(conf_tensor, 0.0, 1.0).item())
            scores[layer_name] = conf
            total += conf
            checked += 1

        avg_conf = float(total / max(checked, 1))
        threshold = float(meta["config"]["verification_threshold"])
        return {
            "verified": bool(avg_conf >= threshold),
            "confidence": avg_conf,
            "layers_checked": int(checked),
            "layer_scores": scores,
            "threshold_used": threshold,
            "selected_layers": meta["selected_layers"],
        }

    def snapshot_selected_layers(self, model: nn.Module, layer_names: Sequence[str]) -> Dict[str, Dict[str, torch.Tensor]]:
        snapshot = {}
        for name in layer_names:
            module = get_module_by_name(model, name)
            item = {"weight": module.weight.detach().cpu().clone()}
            if getattr(module, "bias", None) is not None:
                item["bias"] = module.bias.detach().cpu().clone()
            snapshot[name] = item
        return snapshot

    def restore_selected_layers(self, model: nn.Module, snapshot: Dict[str, Dict[str, torch.Tensor]]) -> None:
        for name, payload in snapshot.items():
            module = get_module_by_name(model, name)
            with torch.no_grad():
                module.weight.copy_(payload["weight"].to(device=module.weight.device, dtype=module.weight.dtype))
                if "bias" in payload and getattr(module, "bias", None) is not None:
                    module.bias.copy_(payload["bias"].to(device=module.bias.device, dtype=module.bias.dtype))


class _LoRALinearAdapter(nn.Module):
    def __init__(self, base: nn.Linear, rank: int = 8, alpha: int = 16, dropout: float = 0.0):
        super().__init__()
        if not isinstance(base, nn.Linear):
            raise TypeError(f"_LoRALinearAdapter expects nn.Linear, got {type(base)}")

        self.base = base
        self.rank = int(rank)
        self.alpha = float(alpha)
        self.scaling = self.alpha / max(self.rank, 1)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        for p in self.base.parameters():
            p.requires_grad = False

        device = base.weight.device
        self.compute_dtype = torch.float32

        self.A = nn.Parameter(
            torch.empty(self.rank, base.in_features, device=device, dtype=self.compute_dtype)
        )
        self.B = nn.Parameter(
            torch.zeros(base.out_features, self.rank, device=device, dtype=self.compute_dtype)
        )

        nn.init.kaiming_uniform_(self.A, a=math.sqrt(5))
        nn.init.zeros_(self.B)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base(x)
        x_lora = self.dropout(x.to(self.compute_dtype))
        delta = F.linear(F.linear(x_lora, self.A), self.B) * self.scaling
        return base_out + delta.to(base_out.dtype)

    def merge(self) -> nn.Linear:
        merged = nn.Linear(
            self.base.in_features,
            self.base.out_features,
            bias=self.base.bias is not None,
            device=self.base.weight.device,
            dtype=self.base.weight.dtype,
        )
        with torch.no_grad():
            delta_w = (self.B @ self.A) * self.scaling
            merged.weight.copy_(self.base.weight + delta_w.to(self.base.weight.dtype))
            if self.base.bias is not None:
                merged.bias.copy_(self.base.bias)
        return merged


class AttackSimulatorLarge:
    def __init__(self, utility_texts: Iterable[str], max_length: int = 128):
        self.utility_texts = [t for t in utility_texts if isinstance(t, str) and t.strip()]
        self.max_length = max_length

    @staticmethod
    def _iter_targets(model: nn.Module, layer_names: Sequence[str]):
        for name in layer_names:
            module = get_module_by_name(model, name)
            yield name, module

    def pruning(self, model: nn.Module, layer_names: Sequence[str], sparsity: float = 0.10, max_quantile_samples: int = 1000000) -> nn.Module:
        with torch.no_grad():
            for _, module in self._iter_targets(model, layer_names):
                weight = module.weight.data
                flat_abs = weight.detach().abs().reshape(-1)
                n = flat_abs.numel()
                if n > max_quantile_samples:
                    idx = torch.randint(0, n, (max_quantile_samples,), device=flat_abs.device)
                    sample = flat_abs[idx].float().cpu()
                else:
                    sample = flat_abs.float().cpu()
                threshold = torch.quantile(sample, sparsity)
                mask = (flat_abs > threshold.to(flat_abs.device, dtype=flat_abs.dtype)).reshape_as(weight)
                module.weight.data.mul_(mask.to(module.weight.dtype))
        return model

    def quantization(self, model: nn.Module, layer_names: Sequence[str], bits: int = 8) -> nn.Module:
        levels = max((2 ** bits) - 1, 1)
        with torch.no_grad():
            for _, module in self._iter_targets(model, layer_names):
                weight = module.weight.data
                min_val = weight.min()
                max_val = weight.max()
                scale = (max_val - min_val) / levels
                if not torch.isfinite(scale) or abs(float(scale)) < 1e-12:
                    continue
                q = torch.round((weight - min_val) / scale)
                module.weight.data.copy_(q * scale + min_val)
        return model

    def noise_injection(self, model: nn.Module, layer_names: Sequence[str], noise_factor: float = 0.002) -> nn.Module:
        with torch.no_grad():
            for _, module in self._iter_targets(model, layer_names):
                std = module.weight.data.float().std().item() + 1e-8
                module.weight.data.add_(torch.randn_like(module.weight.data) * (noise_factor * std))
        return model

    def weight_shuffling(self, model: nn.Module, layer_names: Sequence[str], shuffle_rate: float = 0.05) -> nn.Module:
        with torch.no_grad():
            for _, module in self._iter_targets(model, layer_names):
                flat = module.weight.data.reshape(-1)
                n = max(1, int(flat.numel() * shuffle_rate))
                idx = torch.randperm(flat.numel(), device=flat.device)[:n]
                values = flat[idx].clone()
                values = values[torch.randperm(values.numel(), device=values.device)]
                flat[idx] = values
        return model

    def constrained_adaptation(self, model: nn.Module, tokenizer, layer_names: Sequence[str], lr: float = 2e-7, steps: int = 2, grad_clip: float = 0.10) -> nn.Module:
        original_train_flags = {name: p.requires_grad for name, p in model.named_parameters()}
        target_weight_names = {f"{layer_name}.weight" for layer_name in layer_names}
        target_bias_names = {f"{layer_name}.bias" for layer_name in layer_names}

        trainable_named = []
        rollback = {}
        for name, p in model.named_parameters():
            is_target = (name in target_weight_names) or (name in target_bias_names)
            p.requires_grad = is_target
            if is_target:
                trainable_named.append((name, p))
                rollback[name] = p.data.detach().clone()

        if not trainable_named:
            for name, p in model.named_parameters():
                p.requires_grad = original_train_flags.get(name, True)
            model.eval()
            return model

        trainable_params = [p for _, p in trainable_named]
        optimizer = torch.optim.SGD(trainable_params, lr=lr)
        model.train()
        device = get_input_device(model)

        for step in range(steps):
            text = self.utility_texts[step % len(self.utility_texts)]
            try:
                batch = tokenizer(text, return_tensors="pt", truncation=True, max_length=self.max_length, add_special_tokens=True)
                batch = {k: v.to(device) for k, v in batch.items()}
                optimizer.zero_grad(set_to_none=True)
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch.get("attention_mask", None), use_cache=False)
                logits = outputs.logits
                shift_logits = logits[:, :-1, :].contiguous()
                shift_labels = batch["input_ids"][:, 1:].contiguous()

                vocab_size = shift_logits.size(-1)
                max_label = int(shift_labels.max().item())
                min_label = int(shift_labels.min().item())
                if min_label < 0 or max_label >= vocab_size:
                    break

                loss = F.cross_entropy(
                    shift_logits.float().cpu().view(-1, vocab_size),
                    shift_labels.cpu().view(-1),
                    reduction="mean",
                )
                if not torch.isfinite(loss):
                    break

                loss.backward()
                grads_ok = True
                for _, p in trainable_named:
                    if p.grad is None or not torch.isfinite(p.grad).all():
                        grads_ok = False
                        break
                if not grads_ok:
                    break

                torch.nn.utils.clip_grad_norm_(trainable_params, grad_clip)
                optimizer.step()

                finite_ok = True
                for _, p in trainable_named:
                    if not torch.isfinite(p.data).all():
                        finite_ok = False
                        break
                if not finite_ok:
                    for name, p in trainable_named:
                        p.data.copy_(rollback[name])
                    break

                for name, p in trainable_named:
                    rollback[name] = p.data.detach().clone()

            except Exception:
                for name, p in trainable_named:
                    p.data.copy_(rollback[name])
                break

        for name, p in model.named_parameters():
            p.requires_grad = original_train_flags.get(name, True)
        model.eval()
        return model

    def lora_adaptation(
        self,
        model: nn.Module,
        tokenizer,
        layer_names,
        calibration_texts=None,
        rank: int = 8,
        alpha: int = 16,
        dropout: float = 0.0,
        lr: float = 5e-5,
        steps: int = 200,
        max_length: int = 128,
        grad_clip: float = 1.0,
    ) -> nn.Module:
        model.train()

        texts = list(calibration_texts) if calibration_texts is not None else list(self.utility_texts)
        if not texts:
            model.eval()
            return model

        wrapped_layers = []
        trainable_params = []

        try:
            for layer_name in layer_names:
                module = get_module_by_name(model, layer_name)
                if not isinstance(module, nn.Linear):
                    continue

                adapter = _LoRALinearAdapter(
                    module,
                    rank=rank,
                    alpha=alpha,
                    dropout=dropout,
                )
                set_module_by_name(model, layer_name, adapter)
                wrapped_layers.append((layer_name, adapter))
                trainable_params.extend([adapter.A, adapter.B])

            if not wrapped_layers:
                model.eval()
                return model

            for p in model.parameters():
                p.requires_grad = False
            for _, adapter in wrapped_layers:
                adapter.A.requires_grad = True
                adapter.B.requires_grad = True

            optimizer = torch.optim.AdamW(trainable_params, lr=lr)

            try:
                input_device = model.get_input_embeddings().weight.device
            except Exception:
                input_device = next(model.parameters()).device

            for step_idx in range(int(steps)):
                text = texts[step_idx % len(texts)]
                batch = tokenizer(
                    text,
                    return_tensors="pt",
                    truncation=True,
                    max_length=max_length,
                )
                batch = {k: v.to(input_device) for k, v in batch.items()}

                outputs = model(**batch, labels=batch["input_ids"])
                loss = outputs.loss

                if loss is None or not torch.isfinite(loss):
                    break

                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(trainable_params, grad_clip)
                optimizer.step()

        finally:
            for layer_name, adapter in wrapped_layers:
                try:
                    merged = adapter.merge()
                    set_module_by_name(model, layer_name, merged)
                except Exception:
                    set_module_by_name(model, layer_name, adapter.base)

            for p in model.parameters():
                p.requires_grad = True
            model.eval()

        return model


def calculate_perplexity(model: nn.Module, tokenizer, texts: Iterable[str], max_length: int = 128, ppl_cap: float = 1_000_000.0) -> Tuple[float, bool, str]:
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    device = get_input_device(model)

    with torch.no_grad():
        for text in texts:
            try:
                batch = tokenizer(text, return_tensors="pt", truncation=True, max_length=max_length, add_special_tokens=True)
                batch = {k: v.to(device) for k, v in batch.items()}
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch.get("attention_mask", None), use_cache=False)
                logits = outputs.logits
                shift_logits = logits[:, :-1, :].contiguous()
                shift_labels = batch["input_ids"][:, 1:].contiguous()

                vocab_size = shift_logits.size(-1)
                max_label = int(shift_labels.max().item())
                min_label = int(shift_labels.min().item())
                if min_label < 0 or max_label >= vocab_size:
                    continue

                shift_logits_cpu = shift_logits.float().cpu()
                shift_labels_cpu = shift_labels.cpu()
                loss = F.cross_entropy(shift_logits_cpu.view(-1, vocab_size), shift_labels_cpu.view(-1), reduction="mean")
                loss_val = safe_float(loss.item())
                if not math.isfinite(loss_val) or loss_val > 50:
                    continue

                tokens = int(shift_labels.numel())
                total_loss += loss_val * tokens
                total_tokens += tokens
            except Exception:
                continue

    if total_tokens == 0:
        return ppl_cap, True, "invalid_all_batches"

    avg_loss = total_loss / total_tokens
    if not math.isfinite(avg_loss):
        return ppl_cap, True, "invalid_avg_loss"

    ppl = float(torch.exp(torch.tensor(avg_loss)).item())
    if not math.isfinite(ppl) or ppl > ppl_cap:
        return ppl_cap, True, "ppl_capped"

    return ppl, False, "ok"
